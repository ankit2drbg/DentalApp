<?php

class Ves_TabsHome_IndexController extends Mage_Core_Controller_Front_Action {

}

?>
