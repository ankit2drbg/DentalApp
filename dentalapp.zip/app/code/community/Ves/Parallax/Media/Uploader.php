<?php
class Ves_Parallax_Media_Uploader extends Varien_File_Uploader
{   
}